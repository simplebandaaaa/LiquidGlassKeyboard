package com.umeshtech.liquidglasskeyboard

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

class GlassKeyboardView(context: Context, val onKey: (String) -> Unit) : View(context) {
    private val rows = listOf(
        listOf("q","w","e","r","t","y","u","i","o","p"),
        listOf("a","s","d","f","g","h","j","k","l"),
        listOf("⇧","z","x","c","v","b","n","m","⌫"),
        listOf("?123",",","☻","space",".","↵")
    )
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var downX = 0f
    private var downY = 0f
    private var shift = false
    private var dark = true

    init {
        isFocusable = true
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        paint.shader = LinearGradient(0f, 0f, w, h,
            intArrayOf(0xEE26364A.toInt(), 0xF01B2638.toInt(), 0xF0182233.toInt()),
            null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(0f, 0f, w, h, 30f, 30f, paint)
        paint.shader = null
        paint.color = 0x33FFFFFF
        canvas.drawRoundRect(8f, 8f, w-8f, h-8f, 26f, 26f, paint)

        val top = h * 0.10f
        val rowH = (h * 0.82f) / 4f
        rows.forEachIndexed { ri, row ->
            val gap = 6f
            val side = if (ri == 1) 18f else 8f
            val usable = w - side*2 - gap*(row.size-1)
            val keyW = usable / row.size
            row.forEachIndexed { ci, key ->
                val x = side + ci*(keyW+gap)
                val y = top + ri*rowH
                val wide = when(key) { "space" -> keyW*2.4f; "?123" -> keyW*1.35f; "↵","⌫","⇧" -> keyW*1.15f; else -> keyW }
                val actualX = if (key == "space") x - keyW*0.7f else x
                rect.set(actualX, y+3f, actualX+wide, y+rowH-5f)
                paint.shader = LinearGradient(rect.left, rect.top, rect.left, rect.bottom,
                    intArrayOf(0xBFFFFFFF.toInt(), 0x65DCEBFF, 0x8A9CB5D0.toInt()),
                    null, Shader.TileMode.CLAMP)
                canvas.drawRoundRect(rect, 13f, 13f, paint)
                paint.shader = null
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1.2f
                paint.color = 0xAFFFFFFF.toInt()
                canvas.drawRoundRect(rect, 13f, 13f, paint)
                paint.style = Paint.Style.FILL
                paint.color = 0xFFFFFFFF.toInt()
                paint.textAlign = Paint.Align.CENTER
                paint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                paint.textSize = if (key == "space") 13f else 20f
                val label = when(key) { "space" -> "English"; else -> if (shift && key.length == 1) key.uppercase() else key }
                canvas.drawText(label, rect.centerX(), rect.centerY()+paint.textSize*0.35f, paint)
            }
        }
        paint.color = 0x88FFFFFF.toInt()
        paint.textSize = 11f
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("LIQUID GLASS", w/2f, h-5f, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when(event.action) {
            MotionEvent.ACTION_DOWN -> { downX=event.x; downY=event.y; return true }
            MotionEvent.ACTION_UP -> {
                val top = height * 0.10f
                val rowH = (height * 0.82f) / 4f
                val ri = ((event.y-top)/rowH).toInt()
                if (ri in rows.indices) {
                    val row = rows[ri]
                    val gap=6f
                    val side=if(ri==1) 18f else 8f
                    val keyW=(width-side*2-gap*(row.size-1))/row.size
                    val ci=((event.x-side)/(keyW+gap)).toInt().coerceIn(0,row.lastIndex)
                    var key=row[ci]
                    if (key=="⇧") shift=!shift
                    else if (key=="?123") { /* reserved for symbol layer */ }
                    else {
                        if (shift && key.length==1) key=key.uppercase()
                        onKey(key)
                        if (shift && key.length==1) shift=false
                    }
                    invalidate()
                }
                return true
            }
        }
        return true
    }
}
