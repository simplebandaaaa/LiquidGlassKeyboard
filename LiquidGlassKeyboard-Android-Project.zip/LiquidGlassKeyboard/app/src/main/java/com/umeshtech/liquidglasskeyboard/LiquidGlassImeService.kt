package com.umeshtech.liquidglasskeyboard

import android.inputmethodservice.InputMethodService
import android.view.View

class LiquidGlassImeService : InputMethodService() {
    override fun onCreateInputView(): View {
        return GlassKeyboardView(this) { key ->
            val ic = currentInputConnection ?: return@GlassKeyboardView
            when (key) {
                "⌫" -> ic.deleteSurroundingText(1, 0)
                "↵" -> ic.commitText("\n", 1)
                "space" -> ic.commitText(" ", 1)
                "⇧" -> { }
                else -> ic.commitText(key, 1)
            }
        }
    }
}
