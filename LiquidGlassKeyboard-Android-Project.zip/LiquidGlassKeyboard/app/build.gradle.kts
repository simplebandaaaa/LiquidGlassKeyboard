plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.umeshtech.liquidglasskeyboard"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.umeshtech.liquidglasskeyboard"
        minSdk = 26
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
