Liquid Glass Keyboard - Android project
Minimum Android: 8.0 (API 26)
Package: com.umeshtech.liquidglasskeyboard

Build APK:
1. Upload this project folder to a new GitHub repository.
2. Open Actions and run "Build Liquid Glass Keyboard APK".
3. Download the LiquidGlassKeyboard-debug-apk artifact from the completed workflow.
4. Extract app-debug.apk and install it.
5. Android Settings > System > Languages & input > Virtual keyboard > Manage keyboards.
   Enable Liquid Glass Keyboard, then select it as the current keyboard.

Note: This is a first working prototype. The ?123 and emoji keys are visual placeholders;
the keyboard currently enters English letters, space, backspace and newline.
